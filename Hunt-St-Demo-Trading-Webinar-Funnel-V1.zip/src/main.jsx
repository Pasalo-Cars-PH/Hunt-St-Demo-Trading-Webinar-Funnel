import React, {useState} from "react";
import { createRoot } from "react-dom/client";
import { ArrowRight, Check, ChevronDown, Circle, Menu, X } from "lucide-react";
import "./styles.css";

const framework = [
  ["01","MARKET PREPARATION","Understand the broader market context before looking for individual opportunities."],
  ["02","TRADE SELECTION","Use defined criteria to separate potential setups from market noise."],
  ["03","RISK MANAGEMENT","Think about risk before entering a position rather than after the decision has been made."],
  ["04","REVIEW & REFINEMENT","Review decisions systematically so lessons can be identified and incorporated into the next trading session."]
];
const learn = [
  ["HOW TO PREPARE","Build a repeatable pre-market preparation process."],
  ["HOW TO FILTER OPPORTUNITIES","Develop clearer criteria for evaluating potential setups."],
  ["HOW TO THINK ABOUT RISK","Understand why position sizing and predefined risk matter."],
  ["HOW TO REVIEW YOUR DECISIONS","Create a simple feedback loop for improving your process over time."]
];
const faqs = [
  ["Is this training free?","Yes. The demonstration funnel positions the webinar as a free educational training."],
  ["Is this financial advice?","No. The training is educational and does not constitute personalised financial advice."],
  ["Is trading risk-free?","No. Trading involves risk and losses are possible."],
  ["Do I need previous trading experience?","The final commercial version should specify the intended experience level. For this demo, the training is presented as accessible to traders who want to improve their process."],
  ["Will you guarantee trading results?","No. There are no guarantees of income, returns or trading performance."],
  ["What happens after the webinar?","Attendees can review the educational material and decide whether any next step is appropriate for them."]
];

function Button({children, onClick, variant=""}) {
  return <button className={`btn ${variant}`} onClick={onClick}>{children}</button>
}
function Section({id, eyebrow, title, children, className=""}) {
  return <section id={id} className={`section ${className}`}><div className="container">
    {eyebrow && <p className="eyebrow">{eyebrow}</p>}
    {title && <h2>{title}</h2>}
    {children}
  </div></section>
}
function App(){
  const [mobileOpen,setMobileOpen]=useState(false);
  const [openFaq,setOpenFaq]=useState(null);
  const [submitted,setSubmitted]=useState(false);
  const [error,setError]=useState("");
  const [name,setName]=useState("");
  const [email,setEmail]=useState("");

  const goForm=()=>document.getElementById("register")?.scrollIntoView({behavior:"smooth"});
  const submit=(e)=>{
    e.preventDefault(); setError("");
    if(!name.trim()) return setError("Please enter your first name.");
    if(!/^\S+@\S+\.\S+$/.test(email)) return setError("Please enter a valid email address.");
    setSubmitted(true);
  };

  return <div className="app">
    <header className="nav">
      <div className="nav-inner">
        <a className="brand" href="#top">STRUCTURED <span>TRADING</span></a>
        <nav className={mobileOpen?"nav-links open":"nav-links"}>
          <a href="#framework" onClick={()=>setMobileOpen(false)}>How It Works</a>
          <a href="#learn" onClick={()=>setMobileOpen(false)}>What You'll Learn</a>
          <a href="#fit" onClick={()=>setMobileOpen(false)}>Who It's For</a>
          <a href="#faq" onClick={()=>setMobileOpen(false)}>FAQ</a>
        </nav>
        <Button onClick={goForm}>RESERVE MY FREE SEAT</Button>
        <button className="menu" aria-label="Toggle navigation" onClick={()=>setMobileOpen(!mobileOpen)}>{mobileOpen?<X/>:<Menu/>}</button>
      </div>
    </header>

    <main id="top">
      <section className="hero">
        <div className="hero-glow glow-a"/><div className="hero-glow glow-b"/>
        <div className="container hero-grid">
          <div className="hero-copy reveal">
            <p className="eyebrow">FREE LIVE TRADING TRAINING</p>
            <h1>Learn a More <em>Structured</em> Approach to Trading</h1>
            <p className="lead">Discover a practical framework for preparing for the market, identifying higher-quality opportunities, managing risk, and reviewing your decisions with greater discipline.</p>
            <div className="hero-actions"><Button onClick={goForm}>RESERVE MY FREE SEAT <ArrowRight size={17}/></Button></div>
            <p className="micro">Free live training <i/> Educational content <i/> No obligation</p>
          </div>
          <div className="market-visual reveal" aria-label="Abstract market structure visual">
            <div className="visual-top"><span>MARKET STRUCTURE</span><span>PROCESS / DISCIPLINE</span></div>
            <div className="chart">
              <div className="grid-lines"/>
              <svg viewBox="0 0 600 330" preserveAspectRatio="none">
                <path d="M0 250 L70 205 L120 225 L190 135 L250 170 L320 95 L385 125 L445 70 L510 105 L600 38" fill="none" stroke="currentColor" strokeWidth="2.5"/>
                <path d="M0 275 L600 105" fill="none" stroke="currentColor" strokeOpacity=".22" strokeWidth="1"/>
              </svg>
              <div className="node n1">CONTEXT</div><div className="node n2">SETUP</div><div className="node n3">RISK</div>
            </div>
            <div className="visual-bottom"><span><Circle size={7} fill="currentColor"/> EDUCATIONAL MODEL</span><span>NO PERFORMANCE DATA</span></div>
          </div>
        </div>
      </section>

      <Section eyebrow="THE PROBLEM" title="Most Traders Don't Need More Information. They Need a Better Process." className="problem">
        <div className="split-copy"><p>There is no shortage of market commentary, strategies and opinions.</p><p>The challenge is turning all that information into a consistent decision-making process.</p><p>When every trade starts with a different idea, risk becomes inconsistent and mistakes become harder to identify.</p><p>This training introduces a structured framework designed to help traders think more systematically.</p></div>
      </Section>

      <Section id="framework" eyebrow="THE FRAMEWORK" title="A Structured Process for Better Trading Decisions">
        <div className="framework-head"><span>STRUCTURED TRADING FRAMEWORK™</span><span>FOUR STAGES · ONE PROCESS</span></div>
        <div className="cards framework-cards">{framework.map(([n,t,d],i)=><article className="card framework-card" key={n}><div className="num">{n}</div><div className="card-title">{t}</div><p>{d}</p>{i<3&&<div className="connector" aria-hidden="true">→</div>}</article>)}</div>
      </Section>

      <Section id="learn" eyebrow="WHAT YOU'LL LEARN" title="Inside the Free Training" className="learn-section">
        <div className="cards learn-grid">{learn.map(([t,d])=><article className="card learn-card" key={t}><div className="check"><Check size={15}/></div><div><div className="card-title">{t}</div><p>{d}</p></div></article>)}</div>
        <Button onClick={goForm}>SAVE MY SEAT <ArrowRight size={17}/></Button>
      </Section>

      <Section id="fit" eyebrow="WHO THIS IS FOR" title="Is This Training Right For You?">
        <div className="fit-grid">
          <div className="fit-card positive"><div className="fit-label">THIS MAY BE FOR YOU IF...</div>{["You want a more structured approach to trading.","You find yourself reacting emotionally to market movements.","You consume lots of market information but struggle to turn it into a repeatable process.","You want to improve your decision-making discipline.","You understand that trading involves meaningful risk."].map(x=><div className="fit-item" key={x}><Check size={16}/><span>{x}</span></div>)}</div>
          <div className="fit-card negative"><div className="fit-label">THIS IS NOT FOR YOU IF...</div>{["You're looking for guaranteed returns.","You want a “get rich quick” strategy.","You expect someone else to make trading decisions for you.","You're unwilling to manage risk.","You're looking for personalised financial advice from a free training."].map(x=><div className="fit-item" key={x}><X size={16}/><span>{x}</span></div>)}</div>
        </div>
      </Section>

      <section className="authority"><div className="container authority-inner">
        <div><p className="eyebrow">TRUST / POSITIONING</p><h2>Education First. Process Over Predictions.</h2><p>The purpose of this training is not to predict the market or promise a particular financial outcome. It is designed to introduce a structured way of thinking about trading decisions, preparation, risk and review.</p></div>
        <div className="authority-placeholder"><span>DEMO AUTHORITY SECTION</span><p>Replace with verified presenter credentials, biography and independently verifiable proof before commercial use.</p></div>
      </div></section>

      <section id="register" className="register"><div className="container"><div className="register-card">
        <div className="register-copy"><p className="eyebrow">FREE LIVE TRAINING</p><h2>Reserve Your Seat</h2><p>A concise educational session built around preparation, selection, risk and review.</p><div className="reg-note"><Check size={16}/> No purchase required to attend.</div></div>
        {!submitted ? <form onSubmit={submit} noValidate><label>First Name<input value={name} onChange={e=>setName(e.target.value)} autoComplete="given-name" placeholder="Your first name"/></label><label>Email Address<input value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" type="email" placeholder="you@example.com"/></label>{error&&<p className="form-error" role="alert">{error}</p>}<Button>RESERVE MY FREE SEAT <ArrowRight size={17}/></Button><small>By registering, you agree to receive information relating to this training. You can unsubscribe at any time.</small></form>
        : <div className="success" role="status"><div className="success-mark"><Check/></div><p className="eyebrow">REGISTRATION CONFIRMED</p><h3>YOU'RE IN.</h3><p>Your seat has been reserved.</p><p>Check your inbox for the next steps.</p></div>}
      </div></div></section>

      <Section eyebrow="WHAT HAPPENS NEXT" title="What Happens After You Register?">
        <div className="next-grid">{[["01","REGISTER","Reserve your place using the short form."],["02","ATTEND","Join the live educational session."],["03","DECIDE","Take what you learn and decide whether the framework is relevant to your own goals."]].map(x=><div className="next-step" key={x[0]}><span>{x[0]}</span><div><div className="card-title">{x[1]}</div><p>{x[2]}</p></div></div>)}</div>
      </Section>

      <Section id="faq" eyebrow="FAQ" title="Questions, Answered." className="faq-section">
        <div className="faq">{faqs.map(([q,a],i)=><div className="faq-item" key={q}><button onClick={()=>setOpenFaq(openFaq===i?null:i)} aria-expanded={openFaq===i}><span>{q}</span><ChevronDown className={openFaq===i?"rot":""}/></button>{openFaq===i&&<div className="answer"><p>{a}</p></div>}</div>)}</div>
      </Section>

      <section className="final-cta"><div className="container"><p className="eyebrow">FREE LIVE TRADING TRAINING</p><h2>Trade With a Process.<br/><em>Not With Guesswork.</em></h2><p>Reserve your place for the free live training.</p><Button onClick={goForm}>RESERVE MY FREE SEAT <ArrowRight size={17}/></Button><small>Educational content only. No guaranteed outcomes.</small></div></section>
    </main>

    <footer><div className="container footer-top"><a className="brand" href="#top">STRUCTURED <span>TRADING</span></a><div className="footer-links"><a href="#top">Privacy</a><a href="#top">Terms</a><a href="#top">Risk Disclosure</a></div></div><div className="container footer-bottom"><p>This demonstration page is for educational and portfolio purposes only. Trading and investing involve risk, including the possible loss of capital. Nothing on this page constitutes personalised financial advice or a guarantee of financial performance.</p><span>© 2026 Structured Trading. Demo Project.</span></div></footer>
  </div>
}
createRoot(document.getElementById("root")).render(<App/>);
