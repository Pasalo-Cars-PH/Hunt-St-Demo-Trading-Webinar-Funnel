# Hunt St Demo — Trading Webinar Funnel V1

Portfolio/demo landing page for a fictional premium trading education brand.

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

This demo intentionally has no backend, database, payments, financial APIs, fabricated testimonials, performance claims, or real registration processing.
